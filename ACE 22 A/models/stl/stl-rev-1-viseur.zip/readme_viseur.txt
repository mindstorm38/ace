Penser � imprimer les pi�ce � plat
Et pour "viseur_reglable.stl" trouver un moyen de voir les nombre (si pas possible ce n'est pas grave.